#ifndef PRINT_H
#define PRINT_H

class Print {
public:
    static void printHelloWorld();
};

#endif
